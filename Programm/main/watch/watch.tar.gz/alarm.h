uint8_t edit=0;                     //Edit the Alarm (0 means no edit; 1 means hour; 2 means minute; 3 means second; 4 means Enable/Disable Alarm)


void editAlarm()
{
	switch(edit)
           {
               case 1:
                 hour_alarm++;
                 if(hour_alarm>=24)
                   hour_alarm=0;
               break;
               case 2:
                 minute_alarm++;
                 if(minute_alarm>=60)
                   minute_alarm=0;
               break;
               case 3:
                 second_alarm++;
                 if(second_alarm>=60)
                   second_alarm=0;
               break;
               case 4:
                 tft.setCursor(tft.width()-(8*7), 0);          
                 tft.setTextColor(BACKGROUND_COLOR);
                 tft.setTextSize(1);
                 if(enabled_alarm)
                  tft.println("Enabled");
                 else
                  tft.println("Disabled");
                 enabled_alarm=!enabled_alarm;
                 tft.setCursor(tft.width()-(8*7), 0);          
                 tft.setTextColor(TITLE_COLOR);
                 tft.setTextSize(1);
                 if(enabled_alarm)
                  tft.println("Enabled");
                else
                  tft.println("Disabled");
                break;
           } 
           drawAlarm();        
}