#define NEXT_PAGE 1
#define PREV_PAGE -1
#define LONG_PRESS 3
#define TITLE_PRESS 2

int8_t getTouch()
{
  #ifdef TOUCH
  TS_Point p = ts.getPoint();
  uint8_t timer=0;
  for(int zaehler=0; zaehler<=10&&timer<LONGPRESS_TIME; zaehler++)
  {
    while(ts.touched())
    {     
      p = ts.getPoint();
      p.x = map(p.x, TS_MINX, TS_MAXX, 0, tft.width());
      p.y = map(p.y, TS_MINY, TS_MAXY, 0, tft.height()); 
      delay(TOUCH_DELAY);
      if(timer++>LONGPRESS_TIME)
        break;       
    }                
  }

  if(p.x<(tft.width()-(CLOCK_Y+CLOCK_SIZE*7+10)))
  {
    if(p.y>tft.height()/2)
      return NEXT_PAGE;
    else
      return PREV_PAGE;
  }
  else
  {  
    if(timer>LONGPRESS_TIME)
      return LONG_PRESS;
    else
      return TITLE_PRESS;
  }
  #endif
}